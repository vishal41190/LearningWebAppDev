var main = function(){
    $('.picture').colorbox({
        
        rel:'group1',
        open:'true',
        slideshow: 'true',
       
    });
}

$(document).ready(main);